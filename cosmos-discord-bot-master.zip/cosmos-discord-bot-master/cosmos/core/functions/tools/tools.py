class Tools(object):

    def __init__(self, bot):
        self.bot = bot
