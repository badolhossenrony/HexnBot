from .cog import Cog


__all__ = [
    "Cog",
]
