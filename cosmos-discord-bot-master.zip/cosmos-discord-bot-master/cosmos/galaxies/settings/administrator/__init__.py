from .administrator import AdministratorSettings


__all__ = [
    "AdministratorSettings",
]
