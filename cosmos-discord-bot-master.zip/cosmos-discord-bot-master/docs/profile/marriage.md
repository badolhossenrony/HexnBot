---
description: A Fun plugin which brings members closer than before.
---

# Marriage

## ;propose

Lets you propose them. Luckily, if they have already prosed you, it proceeds for marriage.

```yaml
Aliases:
- proposal
- proposals
- marry
- accept

Usage:
;propose <user>
```

### ;propose decline

Declines proposal if you had any.

```yaml
Aliases:
- reject

Usage:
;propose decline
```

### ;propose cancel

Cancels your proposal you made to someone.

```yaml
Aliases:
- revoke
- pull

Usage:
;propose cancel
```

## ;divorce

Lets you divorce if you're already married to someone.

```yaml
Usage:
;divorce
```

