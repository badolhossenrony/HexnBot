---
description: This plugin implements experience points and levelling features.
---

# \_Levels

