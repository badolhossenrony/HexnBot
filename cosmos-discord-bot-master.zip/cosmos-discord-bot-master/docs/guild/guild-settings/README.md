---
description: Plugin for extra server settings and configurations.
---

# Guild Settings

{% page-ref page="theme.md" %}

{% page-ref page="prefix.md" %}



