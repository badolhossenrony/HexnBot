---
description: Contains worst dead shittiest dankest memes commands. Yo wait you can disable it LMAO.
---

# Dead Memes

## ;spongebobmock

Spongebob mocks provided message or text and sends it back.

```yaml
Usage:
;spongebobmock <message>

Examples:
# Any custom text.
;spongebobmock Frick mock this text please oof LOL oof oof.

# Any older discord message.
;spongebobmock https://discordapp.com/channels/336642139381301249/381963689470984203/706812508131819571
```
