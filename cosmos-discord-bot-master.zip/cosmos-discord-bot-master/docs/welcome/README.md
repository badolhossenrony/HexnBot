---
description: A plugin to greet newly joined members using Welcome Messages and Banners.
---

# Welcome

## ;welcome

Manage different welcome settings of your server.

```yaml
Aliases:
- join

Usage:
;welcome
```

