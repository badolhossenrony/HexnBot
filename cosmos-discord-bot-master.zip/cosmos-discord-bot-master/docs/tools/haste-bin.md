---
description: An utility plugin for Hastebin.
---

# Haste Bin

## ;hastebin

Posts the provided content to [https://hastebin.com/](https://hastebin.com/) and displays a shareable link.

```yaml
Aliases:
- haste

Usage:
;hastebin <content>
```

