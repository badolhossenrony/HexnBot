# Donors and Supporters

We are really thankful to all of our supporters and caretakers. Without them, Cosmos wouldn't be as it is today. We are also grateful for our patrons and we hope the incentives you get for your generosity make you happy enough to stay.

## Patreon Strings

![](../.gitbook/assets/string.png)

* **EminaKoju**

## Patreon Quarks

![](../.gitbook/assets/quark.png)

* **Катюша Каблашников**

## Patreon Neutrinos

![](../.gitbook/assets/neutrino.png)

