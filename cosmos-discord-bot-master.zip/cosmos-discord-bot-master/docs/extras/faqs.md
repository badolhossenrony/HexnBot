# FAQs

## Ask Questions.

We are happy to help you. Visit our [discord community](https://discord.gg/7CrQEyP).

## ~~Can I become who I want to be?~~

~~That's a tough question but thankfully, our team is on it. Please bear with us while we're investigating.~~

## ~~How to pass?~~

~~Yes, after a few months we finally found the answer. Sadly, Mike is on vacations right now so I'm afraid we are not able to provide the answer at this point.~~

