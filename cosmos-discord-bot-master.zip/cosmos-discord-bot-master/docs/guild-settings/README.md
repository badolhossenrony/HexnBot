---
description: Plugin for extra server settings and configurations.
---

# Guild Settings

